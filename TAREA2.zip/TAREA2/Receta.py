from Medicamento import Medicamento
from Paciente import Paciente
import datetime
from DetalleReceta import Detalle_Receta
from Empresa import Empresa

class Receta:
    def __init__(self, Id, Cedula, Paciente, Edad, Telefono):
        self.id = Id
        self.Id_Detalle = []
        self.ce = Cedula
        self.pa = Paciente
        self.edad = Edad
        self.tele = Telefono
        self.fecha = datetime.date.today()

    def AgregarReceta(self, id, id_Medicamento, pres):
        rec = Detalle_Receta(id, id_Medicamento, pres)  # Relacion de composicion   Instancias detalle de receta en receta
        self.Id_Detalle.append(rec)

    def MostrarReceta(self, razon, ruc, dir):
        print("=" * 26, "Receta", "=" * 26)
        print(" "*20, f"{razon}", " "*20)
        print(" "*21,f"{ruc}"," "*21)
        print(" "*23,f"{dir}"," "*23,)
        print(f"""Paciente: {self.pa.nombre}    Cedula: {self.ce}    Fecha: {self.fecha}
Edad: {self.edad}    Telefono: {self.tele}        """)
        print("=" * 23, "Detalle Receta", "=" * 23)
        print("Codigo Medicamento Prescripcion ")

        for j in self.Id_Detalle:
            print(f"{j.id}      {j.id_Medicamento.nom_co}        {j.prescripcion}")

# emp = Empresa()
# pac = Paciente(1, "Moises", "0940492410", "21/07/2001", "ecuatoriano", "Milagro", "Soltero", "0949302", "O+", "S/A")
# rec = Receta(1, "0706618998", pac, "24", "0969323907")  # Agregacion
# med=Medicamento(1,"Analgan", "Paracetamol", "284", "12-05-2022", "12-06-2023", "LT215", "$1")
# rec.AgregarReceta(1, "Cada 8h", med)
#     #Asociacion
# rec.MostrarReceta(emp.razon_social,emp.ruc,emp.dir)