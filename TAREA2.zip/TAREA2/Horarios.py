class Horarios:
    def __init__(self, id, fecha, hora, ho_emergencia):
        self.id = id
        self.fecha = fecha
        self.hora = hora
        self.ho_emergencia = ho_emergencia
