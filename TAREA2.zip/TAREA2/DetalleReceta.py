from Medicamento import Medicamento
class Detalle_Receta:
    def __init__(self, id, pres, id_Medicamento):
        self.id = id
        self.id_Medicamento = id_Medicamento
        self.prescripcion = pres
    def MostrarMedicamento(self):
        cr7 = f"{self.id} {self.prescripcion} {self.id_Medicamento.nom_co}"
        return cr7
if __name__ == '__main__':
    #Agregacion
    #Instancias fueras de la clase
    med=Medicamento(1,"Analgan", "Paracetamol", "284", "12-05-2022", "12-06-2023", "LT215", "$1")
    det=Detalle_Receta(1, "Malestar", med)
    print(det.MostrarMedicamento())