from Paciente import Paciente
class Diagnostico:
    def __init__(self, id, id_paciente,diag):
        self.id = id
        self.id_paciente = id_paciente
        self.diagnostico = diag
    def MostrarDiagnostico(self):
        siu = f"{self.id} {self.id_paciente.nombre} {self.id_paciente.identificacion} {self.diagnostico}"
        return siu

pa=Paciente(1,"Miguel", "0940492416", "09/02/2002", "ecuatoriano", "Duran", "Soltero", "0949302", "O+", "S/A")
diag=Diagnostico(1,pa,"Dolor Muscular")
print(diag.MostrarDiagnostico())
