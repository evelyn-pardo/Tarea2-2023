class Paciente:
    def __init__(self, id, nombre, identificacion, fe_nacimiento, nacionalidad, direccion, estadocivil,
                 telefono, tiposangre, antesedentes):
        self.id = id
        self.nombre = nombre
        self.identificacion = identificacion
        self.fe_nacimiento = fe_nacimiento
        self.nacionalidad = nacionalidad
        self.direccion = direccion
        self.estadocivil = estadocivil
        self.telefono = telefono
        self.tiposangre = tiposangre
        self.antesedentes = antesedentes

    def mostrarPaciente(self):
        return f"{self.nombre}"
